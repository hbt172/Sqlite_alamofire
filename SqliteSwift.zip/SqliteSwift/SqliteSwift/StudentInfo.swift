
import UIKit

class StudentInfo: NSObject {
    var RollNo: String = String()
    var Name: String = String()
    var Marks: String = String()
}
