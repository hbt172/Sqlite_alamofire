
import UIKit
//import Alamofire
//   pod 'Alamofire', '~> 4.2.0'  podfile

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
  var marrStudentData : NSMutableArray!
    @IBOutlet var lblName: UILabel!
    
    @IBOutlet var lblMarks: UILabel!
    
    @IBOutlet var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblName.text! = "jayati"
        lblMarks.text! = "100"
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // MARK: - Forgot WebService
    
//    func ForgotWebServices() {
//        
//        Alamofire.request( "URL", method: .post, parameters:["email_id" : txtEmail.text!]).responseJSON { (responseData) -> Void in
//            if((responseData.result.value) != nil) {
//                
//                let dic = responseData.result.value as! NSDictionary
//                
//                if (dic["status"]!)as! String == "Success"
//                {
//                    let alert = UIAlertController(title: "", message: (dic["message"]!)as? String, preferredStyle: UIAlertControllerStyle.alert)
//                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (UIAlertAction)in
//                        
//                        self.removeAnimation()
//                    }))
//                    self.present(alert, animated: true, completion: nil)
//                    
//                    
//                    
//                }
//                else{
//                    let alert = UIAlertController(title: "", message: (dic["message"]!)as? String, preferredStyle: UIAlertControllerStyle.alert)
//                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
//                    self.present(alert, animated: true, completion: nil)
//                }
//            }
//            
//        }
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    @IBAction func onbtnSubmitAction(_ sender: Any) {
        
        let studentInfo: StudentInfo = StudentInfo()
        studentInfo.Name = lblName.text!
        studentInfo.Marks = lblMarks.text!
        let isInserted = ModelManager.getInstance().addStudentData(studentInfo: studentInfo)
        if isInserted {
            Util.invokeAlertMethod(strTitle: "", strBody: "Record Inserted successfully.", delegate: nil)
        } else {
            Util.invokeAlertMethod(strTitle: "", strBody: "Error in inserting record.", delegate: nil)
        }
        
        
        getStudentData()
    }
    func getStudentData()
    {
      marrStudentData = NSMutableArray()
        marrStudentData = ModelManager.getInstance().getAllStudentData()
        tblView.delegate = self
        tblView.dataSource = self
        tblView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return marrStudentData.count
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell  {
        let cell  = tblView.dequeueReusableCell(withIdentifier: "Cell")
        let student:StudentInfo = marrStudentData.object(at: indexPath.row) as! StudentInfo
        cell?.textLabel?.text = "Name : \(student.Name)  \n  Marks : \(student.Marks)"
      
        return cell!
    }
    
}

